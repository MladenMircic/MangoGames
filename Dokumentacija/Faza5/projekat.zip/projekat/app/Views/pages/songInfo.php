<div class="offset-sm-3 col-sm-6 infoPart">
    <h3>Song info</h3>
    <table class="table songInfoTable">

    </table>
    <input type="button" class="btn btn-sm btn-light" value="Play">
</div>