
<div class="loginFooter">
    Don't have an account?
    <br>
    <?php echo anchor(site_url("Register"), "Register") ?>
</div>

